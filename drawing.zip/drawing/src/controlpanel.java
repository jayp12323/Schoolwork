import java.util.Random;
import java.awt.*;
import java.awt.event.*;

import javax.swing.*;
import javax.swing.event.*;

class controlpanel extends JPanel
{
	JTextArea output;
	DrawRooms draw;
	int[][] room;
	ActionHandler action;
	JButton help;
	JButton start;
	Graphics page;
	controlpanel(JTextArea outputarea,DrawRooms dr,int[][] rooms)
	{
		this.output = outputarea;
		this.draw = dr;
		this.room = rooms;
		action = new ActionHandler();
		help = new JButton("turn left");
		help.addActionListener(action);
	    start = new JButton("turn right");
	    start.addActionListener(action);
	    this.add(help);
	    this.add(start);
	}
	
	public void setborder() {
		this.setBorder(BorderFactory.createLineBorder(Color.black));
		
	}
	
	
	
}
class ActionHandler implements ActionListener
{
	
	public void actionPerformed(ActionEvent e) {
		if (e.getActionCommand().equals("turn right")) // help button pressed
        {
//			
//			dr.setturn("right");
//			dr.repaint();
//
//			
			
        }
		if (e.getActionCommand().equals("turn left")) // help button pressed
        {
			
			DrawRooms dr = new DrawRooms();
			dr.setturn("left");
			dr.repaint();

//			dr.paintleft(page);
			
			
        }
	
	}
	
}