
//********************************************************************
//  DrawRooms - Application version  -     
//  Draws room - marks a 1 for those which have a door
// places prisoner , tiger and lily images on the grid      
//  Sets up a grid of rooms   -
// USE CODE FROM CHECKERS TO SET UP THE GRID
//********************************************************************

import java.awt.*;

import javax.swing.*;
import java.util.*;
import java.util.Timer;
import java.awt.event.*;
import java.util.ArrayList;
import java.net.*;


//********************************************************************
// CREATE A TWO-D ARRAY OF ROOMS(LIKE THE ONE OF SQUARES in Checkers

//
// DECLARE THREE IMAGES AS BELOW  - YOU WILL USE IMAGEICONS
//
// I GIVE CODE ON HOW TO SCALE THE IMAGE  - this is easiest way -  can also do it with TWO D graphics method


@SuppressWarnings({ "unused", "serial" })
public class DrawRooms  extends JPanel
{


	int x1 = 0;
	 int[][] Arooms;
	 int w,h;
	 Graphics2D p2;
	 String turn = "middle";
	 int numroom = 22;
	 ImageIcon imgTigerSmall;


	// declare instance variables, fonts used and images  - (they will all be ImageIcons)
	
	// also a constant for number of rooms(22)   - 

	
	//DECLARE BUT DO NOT INSTANTIATE A TWO D ARRAY OF INTEGERS - AROOMS - TO STORE THE ARRAY SENT IN THE CONSTRUCTOR 
	// BELOW FROM THE GUI CLASS
	
		// CONSTRUCTOR
	public DrawRooms()
	   {
//		 Image image1 = null;
		 
		// THIS WILL ASSIGN A REFERENCE TO ARRAY OF INTS CREATED  IN GUI CLASS
	    this.Arooms = Arooms;
	    w = 800;
	    h = 470;
		
		// YOU NEED TO SET THE PREFERRED SIZE TO GET THE DISPLAY THE SIZE YOU WANT IT.
		 setPreferredSize(new Dimension( w, h));
		 
	//	  CREATE  THREE  IMAGEICONS E.G. THIS SHOWs HOW TO SCALE IT

//		  ImageIcon imgTigerSmall = new ImageIcon();  // create the imageicon
//			Image image = imgTigerSmall.getImage(); // get an image object from it
//	        image  = image.getScaledInstance(38, 38, Image.SCALE_SMOOTH);// reduce its size
//	       imgTigerSmall = new ImageIcon(image); // change it back to an imageIcon
//		  
		  
//       setBackground(Color.yellow);

 
	  }
	  
	  // this method is called from the Controller class to reset where the prisoner will be at the end of run.
	  
	  public int getW() {
		return w;
	}

	public void setW(int w) {
		this.w = w;
	}

	public int getH() {
		return h;
	}

	public void setH(int h) {
		this.h = h;
	}


	public Graphics2D getP2() {
		return p2;
	}

	public void setP2(Graphics2D p2) {
		this.p2 = p2;
	}
	
	public void setturn(String s){
		turn = s; 
	}

	public String getturn(){
		return turn; 
	}
	
	// repaint() this will cause paintComponent to be called again and the prisoner to be moved to position x1
	  public void MoveMan( int x1)
	  {
	    this.x1 = x1;
		 repaint();
	}
	//------------------------------------------------'
	//	this is just like checkers - 
	// calls fillRooms method and sets background color
	//------------------------------------------------
	public void paintComponent (Graphics page)
	{
	 super.paintComponent(page);
	 p2 = (Graphics2D)page;

	 //drt drawright = new drt(p2,w);
	// t.schedule(drawright, 4000);
	 if(turn=="middle")
		 drawroom();
	 if(turn=="right")
		 drawrightturn();
	 if(turn=="left")
		 drawleftturn();
	
	 //drawleftturn(p2);
//	 drawrightturn(p2);
		
	} // end paint method
	
		
	//------------------------------------------------
	//	A method to fill the grid with rooms  - use same method you used in Checkers fillboard
	//------------------------------------------------
	public void drawroom ()
	{
		 int[] lvarx = {0,w/5,w/5,0}; //left wall
		 int[] lvary = {0,0,370,469};
		 
		 int[] rvarx = {w/5*4,w,w,w/5*4}; //right wall
		 int[] rvary = {0,0,469,370};
		 
		 int[] cvarx = {w/5,w/5*4,w/5*4,2/5}; // center wall
		 int[] cvary = {0,0,370,370};
		 
p2.setPaint(new GradientPaint(w/2, 0,new Color(250,250,250), w/2, 470, new Color(80,80,80)));
p2.fillPolygon(lvarx, lvary, 4);
p2.fillPolygon(rvarx, rvary, 4);
p2.fillPolygon(cvarx, cvary, 4);
p2.setColor(new Color(102/2, 102, 170/2));
//floor
int[] bvarx = {w/5,w/5*4,w,0};
int[] bvary = {370,370,469,469};
p2.fillPolygon(bvarx, bvary, 4);




p2.setPaint(new GradientPaint(w/2, 90,new Color(144,0,0), w/2, 340, new Color(40,0,0)));

//		 p2.setColor(new Color(144,0,0));
		 
		p2.fillRect(w/2-126/2, 90, 126, 280); //door
		p2.setColor(Color.black);
		p2.drawRect(w/2-126/2, 90, 126, 280);//door frame
		p2.fillOval(w/2-126/2+5, 220, 10, 10); //doorknob
		p2.drawRect(0, 0, w, 469); //room frame
		p2.drawLine(w/5, 0, w/5, 370); //back left corner
		p2.drawLine(w/5, 370, 0, 469); //left floor 
		p2.drawLine(w/5*4, 0, w/5*4, 370); //back right corner 
		p2.drawLine(w/5*4, 370, w, 469); //right floor
		p2.drawLine(w/5, 370, w/5*4, 370); //center floor
		p2.drawLine(w/2,0,w/2,5); //light fixture
		p2.setColor(new Color(255,255,128));
		p2.fillOval(w/2-5, 5, 10, 10); //light
					   		
	} // end  method
	
	public void drawleftturn ()
	{
		
		 int[] lvarx = {0,w/2,w/2,0}; //left wall
		 int[] lvary = {0,0,h/4*3,h};
		 
		 int[] rvarx = {w/2,w,w,w/2}; //right wall
		 int[] rvary = {0,0,h,h/4*3};
		
		 p2.setPaint(new GradientPaint(w/2, 0,new Color(250,250,250), w/2, h, new Color(80,80,80)));
		 p2.fillPolygon(lvarx, lvary, 4);
		 p2.fillPolygon(rvarx, rvary, 4);
		
		
		p2.setColor(new Color(102/2, 102, 170/2));
		//floor
		int[] bvarx = {w/2,w,0};
		int[] bvary = {h/4*3,h,h};
		p2.fillPolygon(bvarx, bvary, 3);
		
		
		p2.setPaint(new GradientPaint(w/2, 90,new Color(144,0,0), w/2, 340, new Color(40,0,0)));
		
		//right door
		int[] rdvarx = {w-60,w,w,w-60};
		int[] rdvary = {h-(18+355),h-355,h,h-18};
		//left door
		int[] ldvarx = {60,0,0,60};
		int[] ldvary = {h-(18+355),h-355,h,h-18};
		p2.fillPolygon(rdvarx,rdvary,4); //door
		p2.fillPolygon(ldvarx, ldvary, 4);
		p2.setColor(Color.black);
		p2.fillOval(w-60+5, h-(18+355/2), 10, 10); //doorknob		

		
		
		
		
		p2.drawRect(0, 0, w-1, 469); //room froame
		p2.drawLine(w/2,h/4*3 , 0, h-1); //left floor 
		p2.drawLine(w/2, h/4*3, w-1, h-1); //right floor
		p2.drawLine(w/2, 0, w/2, h/4*3); //center
		
		p2.drawLine(w/2+w/10,0,w/2+w/10,5); //light fixture
		p2.setColor(new Color(255,255,128));
		p2.fillOval(w/2+w/10-5, 5, 10, 10); //light
		

	}
	
	public void drawrightturn ()
	{

		
		 int[] lvarx = {0,w/2,w/2,0}; //left wall
		 int[] lvary = {0,0,h/4*3,h};
		 
		 int[] rvarx = {w/2,w,w,w/2}; //right wall
		 int[] rvary = {0,0,h,h/4*3};
		 
		
		 p2.setPaint(new GradientPaint(w/2, 0,new Color(250,250,250), w/2, h/4*3, new Color(80,80,80)));
		 p2.fillPolygon(lvarx, lvary, 4);
		 p2.fillPolygon(rvarx, rvary, 4);
		 
			p2.setColor(new Color(102/2, 102, 170/2));
			//floor
			int[] bvarx = {w/2,w,0};
			int[] bvary = {h/4*3,h,h};
			p2.fillPolygon(bvarx, bvary, 3);
		 
			p2.setPaint(new GradientPaint(w/2, 90,new Color(144,0,0), w/2, 340, new Color(40,0,0)));

			//right door
			int[] rdvarx = {w-60,w,w,w-60};
			int[] rdvary = {h-(18+355),h-355,h,h-18};
			//left door
			int[] ldvarx = {60,0,0,60};
			int[] ldvary = {h-(18+355),h-355,h,h-18};
			p2.fillPolygon(rdvarx,rdvary,4); //door
			p2.fillPolygon(ldvarx, ldvary, 4);
			p2.setColor(Color.black);
			p2.fillOval(w-60+5, h-(18+355/2), 10, 10); //doorknob	
		 
		 
		p2.setColor(Color.black);
		p2.drawRect(0, 0, w-1, 469); //room froame
		p2.drawLine(w/2,h/4*3 , 0, h-1); //left floor 
		p2.drawLine(w/2, h/4*3, w-1, h-1); //right floor
		p2.drawLine(w/2, 0, w/2, h/4*3); //center
		p2.drawLine(w/2-w/10,0,w/2-w/10,5); //light fixture
		p2.setColor(new Color(255,255,128));
		p2.fillOval(w/2-w/10-5, 5, 10, 10); //light

		
	}
	
} // end FillRoomclass

