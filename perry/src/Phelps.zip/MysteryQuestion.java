//package com.wingspan.interview;

/**
 * Add comments to the method below without changing any of the code so as to
 * indicate what is happening in a meaningful sense. Write a summary comment
 * above the method itself that explains what the method does and provides any
 * other useful notes regarding its use or behavior that you feel are relevant.
 */
public class MysteryQuestion {
	public static String function(String s) {
		
		// if the string inputted in the paramater is either null or if the length of the string array
		// not 9 (10 different values), it throws a RuntimeException. 
		if (s == null || s.length() != 9) {
			throw new RuntimeException();
		}
		// sets up a Stringbuffer to hold the modified string 
		StringBuffer sb = new StringBuffer();
		
		// what this does is turns the inputted string of length 9 into a phone number format. 
		// ie 111111111 -> (111)111-1111. It does not care what the characters are. It appears to not 
		// be completely right because it only works for (111)111-111
		for (int i = 0; i < 9; i++) {
			if (i == 0) {
				sb.append('(');
			} else if (i == 3) {
				sb.append(')');
			} else if (i == 6) {
				sb.append('-');
			}

			char c = s.charAt(i);
			//if the ith character of the string is a number, nothing else needs to be done to it,
			//and it is left alone
			if (Character.isDigit(c)) {
				sb.append(c);
				// if the character is a letter, it converts a letter to the corresponding number 
				//on a telephone, ie A=2,m=6 etc 
				 
			} else if (Character.isLetter(c)) {
				char c1 = (char) (Character.toLowerCase(c) - 'a');
				char c2 = (char) (((int) '2') + (c1 / 3));

				sb.append(c2);
				
				//if the ith character is neither a letter or a number, throw a RuntimeException
			} else {
				throw new RuntimeException();
			}
		}
		// prints the stringbuffer to the console if it completes successfully
		return sb.toString();
	}
}
