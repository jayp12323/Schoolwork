//package com.wingspan.interview.stringaudit;

public abstract class StringAuditQuestion
{
	public static class Pair
	{
		public char _char;
		public int _occurances;

		public Pair(char c)
		{
			_char = c;
			_occurances = 0;
		}
	}

	/**
	 * Breaks down a string into an array of pairs which report each character
	 * that appears in the string, along with the number of occurances for that character.
	 * This report is to be provided in order from most occuring character to least occurring
	 * character
	 * 
	 * @param input Any non-null string
	 * @return returns the contents of the string
	 */
	public abstract Pair[] auditString(String input);

	public void reportAudit(String input)
	{
		Pair[] pairs = auditString(input);
		for (int i = 0; i < pairs.length; i++)
		{
			System.out.println(pairs[i]._char + "\t" + pairs[i]._occurances);
		}		
	}
}

class StringAudit extends StringAuditQuestion
{

	
	public Pair[] auditString(String input) {
		if (input == null) {
			throw new RuntimeException();
		}
		Pair[] p = new Pair[input.length()];
		int pairnum = 0;
		for(int i = 0; i <input.length();i++)
		{
			char c = input.charAt(i);
			Pair temp = new Pair(c); 
			int j = 0;
			boolean found = false;
			if(i>0)
			{
			    while(j++<pairnum)
			    	  if (temp._char==(p[j]._char))
			    	  {
			    		  p[j]._occurances++;
			    		  found = true;
			    	  }	
				if (found == false)
					p[pairnum] = new Pair(c);
					pairnum++;
			}
		}
		return p ;
		
	}

	
}